# Flesh Xeno — Offline Android Assistant (v1.1)

Kotlin + Jetpack Compose chat app. Fully offline (no INTERNET permission). Replies are rule-based, not a generative AI model.

## Features
- Calculator: `25*4+10`, `2^8`, `(5+3)*2`, `12 x 12`
- Percent: `20% of 500`
- Unit convert: `5 km to miles`, `30 c to f`, `70 kg to lb`, `10 cm to inch`, `6 ft to m`
- Time, date, day
- Jokes, quotes, fun facts, coin flip, dice, random number (`random number 1 to 10`)
- Hinglish / Hindi / English small talk
- Chat history saved on device, Clear button, quick-action buttons, selectable text

## Build APK
### Option A: GitHub Actions (no PC needed)
1. Create a GitHub repo, upload everything inside this folder (keep `.github/` at repo root).
2. Actions tab > "Build Flesh Xeno APK" > Run workflow.
3. Download artifact `FleshXeno-debug-apk` -> `app-debug.apk`.

### Option B: Android Studio
1. Open this folder, JDK 17, let Gradle sync.
2. Build > Build APK(s). Output: `app/build/outputs/apk/debug/app-debug.apk`.

Install on phone: allow "Install unknown apps".

## Customize
Edit `OfflineBrain.reply()` in `OfflineBrain.kt` — add new `has(...) -> "reply"` branches, or extend the jokes/quotes/facts lists.
