package com.fleshxeno.assistant

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.random.Random

/**
 * Offline, rule-based responder. Not a language model.
 * Add new intents inside reply() or new lists below.
 */
object OfflineBrain {

    private val jokes = listOf(
        "Teacher: Wi-Fi kya hota hai? Student: Woh cheez jo ghar mein sabko jodti hai, par password kisi ko nahi pata! 😄",
        "Patni: Suno, main mote lag rahi hu? Pati: Nahi... (jaan bachane ke liye 3 minute soch ke) ...bilkul nahi! 😅",
        "Bhai exam me itna padha tha ki question paper dekh ke laga galat building me aa gaya hu. 😂",
        "Doctor: Aapko aaram ki zaroorat hai. Mareez: Par mera Wi-Fi to kaam kar raha hai doctor sahab! 🤣",
        "Alarm: subah 6 baje. Main: 6:05, 6:10, 6:15... Zindagi: ab to uth ja bhai. 😴",
        "Dost: Tu itna chup kyun hai? Main: Battery low hai, 1% pe hu. 🔋"
    )

    private val quotes = listOf(
        "Chhote chhote kadam bhi manzil tak le jaate hain. Bas rukna mat. 💪",
        "Jo aaj mushkil lag raha hai, kal wahi teri taakat banega. 🔥",
        "Perfect time kabhi nahi aata. Abhi shuru kar, raaste khud ban jaate hain. 🚀",
        "Girna fail hona nahi hota. Girke na uthna fail hona hota hai. 🌱",
        "Roz ka 1% behtar hona, saal bhar me bahut bada farak laa deta hai. 📈",
        "Apni raftaar se chal, bas chalta reh. 🐢➡️🏁"
    )

    private val facts = listOf(
        "Octopus ke 3 dil hote hain. 🐙",
        "Venus par ek din (ek chakkar) uske ek saal se bhi lamba hota hai. 🪐",
        "Shahad (honey) lagbhag kabhi kharab nahi hota. Purane maqbaron me hazaaron saal purana shahad mila hai jo ab bhi theek tha. 🍯",
        "Insaan ka dimaag body ki lagbhag 20% energy use karta hai, jabki uska vajan sirf 2% hota hai. 🧠",
        "Botany ke hisaab se kela (banana) ek berry hai, par strawberry nahi. 🍌",
        "Shatranj (chess) ka puraana roop 'chaturanga' Bharat me bana tha. ♟️"
    )

    private val units = mapOf(
        "km" to "km", "kilometer" to "km", "kilometers" to "km",
        "mile" to "mi", "miles" to "mi",
        "kg" to "kg", "kilo" to "kg", "kilos" to "kg",
        "pound" to "lb", "pounds" to "lb", "lb" to "lb", "lbs" to "lb",
        "c" to "c", "celsius" to "c",
        "f" to "f", "fahrenheit" to "f",
        "cm" to "cm",
        "inch" to "in", "inches" to "in",
        "m" to "m", "meter" to "m", "meters" to "m",
        "ft" to "ft", "feet" to "ft", "foot" to "ft"
    )

    private const val HELP_TEXT =
        "Main ye sab kar sakta hu:\n" +
            "• Calculator: 25*4+10, 2^8, (5+3)*2\n" +
            "• Percent: 20% of 500\n" +
            "• Convert: 5 km to miles, 30 c to f, 70 kg to lb\n" +
            "• Time, date, aaj ka din\n" +
            "• Joke, quote, fun fact\n" +
            "• Coin flip, dice, random number\n" +
            "• Baatein: hi, kaise ho, thanks, bye\n\n" +
            "Chat offline save rehti hai. Main full AI nahi hu, rules se jawab deta hu."

    fun reply(raw: String): String {
        val text = raw.trim()
        val q = text.lowercase(Locale.ROOT)
        val words = q.split(Regex("[^\\p{L}\\p{M}\\p{N}]+")).filter { it.isNotEmpty() }.toSet()

        fun has(vararg keys: String): Boolean = keys.any { k ->
            if (k.contains(' ')) q.contains(k) else words.contains(k)
        }

        tryConvert(q)?.let { return it }
        tryPercent(q)?.let { return it }
        if (has("random", "rand")) return randomNumber(q)
        tryCalculate(text)?.let { return it }

        return when {
            has("good morning", "suprabhat", "शुभ प्रभात") ->
                "Good morning! ☀️ Aaj ka din shandar ho. Kuch madad chahiye?"
            has("good afternoon") ->
                "Good afternoon! 🌤️ Kaisa chal raha hai din?"
            has("good evening") ->
                "Good evening! 🌆 Batao, kya haal hai?"
            has("good night", "shubh ratri", "gn") ->
                "Good night! 🌙 Achhi neend lena."
            has("how are you", "how r u", "kaise ho", "kaisa hai", "kya haal", "kya hal", "कैसे हो") ->
                "Main badhiya hu! 😊 Tum batao, kaise ho?"
            has("your name", "who are you", "tumhara naam", "tera naam", "naam kya", "aap kaun", "tum kaun", "तुम कौन") ->
                "Mera naam Flesh Xeno hai, tumhara offline assistant. 🤖"
            has("who made you", "who created you", "kisne banaya", "tumhe kisne") ->
                "Mujhe ek developer ne Kotlin aur Jetpack Compose me banaya hai. 🛠️"
            has("time", "samay", "baje", "टाइम", "समय") ->
                "Abhi device ke hisaab se ${fmtDate("h:mm a")} hai. 🕒"
            has("date", "tarikh", "tareekh", "तारीख") ->
                "Aaj ki date ${fmtDate("dd MMMM yyyy")} hai, ${fmtDate("EEEE")}. 📅"
            has("day", "din", "weekday") ->
                "Aaj ${fmtDate("EEEE")} hai. 📅"
            has("joke", "jokes", "chutkula", "chutkule", "mazak", "मजाक", "चुटकुला") ->
                pick(jokes)
            has("quote", "quotes", "motivation", "motivate", "suvichar", "inspire", "प्रेरणा") ->
                pick(quotes)
            has("fact", "facts", "gyan", "interesting") ->
                "Fun fact: " + pick(facts)
            has("coin", "toss", "sikka", "सिक्का") ->
                if (Random.nextBoolean()) "Coin uchhala... Heads! 🪙" else "Coin uchhala... Tails! 🪙"
            has("dice", "pasa", "pansa", "ludo") ->
                "Dice roll: ${Random.nextInt(1, 7)} 🎲"
            has("bored", "bore", "boring") ->
                "Bore ho rahe ho? 😄 'joke', 'fun fact' ya 'quote' try karo, ya 'flip coin' aur 'roll dice' se khel lo!"
            has("sad", "udaas", "udas", "dukhi", "upset", "stressed", "tension", "akela") ->
                "Sunke bura laga. 💙 Gehri saans lo, thoda paani piyo. Kisi apne se baat karna bhi bahut madad karta hai. Main yahan hu, chaho to ek joke suna dun?"
            has("thanks", "thank", "thanx", "thx", "shukriya", "dhanyavaad", "धन्यवाद") ->
                "You're welcome! 😊"
            has("bye", "goodbye", "alvida", "tata", "see you", "phir milte", "bye bye") ->
                "Bye! 👋 Phir milte hain."
            has("help", "kya kar", "what can you do", "commands", "madad", "मदद") ->
                HELP_TEXT
            has("hello", "hi", "hii", "hiii", "hey", "hola", "namaste", "namaskar", "salaam", "नमस्ते", "हाय") ->
                "Hello! 👋 Batao, aaj main tumhari kya help karun? ('help' likho to pata chalega main kya kar sakta hu)"
            else ->
                "Is sawaal ka jawab mere paas abhi nahi hai 😅 Main offline hu aur sirf built-in cheezein jaanta hu. 'help' likh ke dekho main kya kar sakta hu."
        }
    }

    // ---------- helpers ----------

    private fun <T> pick(list: List<T>): T = list[Random.nextInt(list.size)]

    private fun fmtDate(pattern: String): String =
        SimpleDateFormat(pattern, Locale.getDefault()).format(Date())

    private fun fmt(v: Double): String {
        if (v == Math.floor(v) && Math.abs(v) < 1e15) return v.toLong().toString()
        return String.format(Locale.US, "%.6f", v).trimEnd('0').trimEnd('.')
    }

    private fun randomNumber(q: String): String {
        val m = Regex("(\\d+)\\D+(\\d+)").find(q)
        var lo = 1
        var hi = 100
        if (m != null) {
            val a = m.groupValues[1].toIntOrNull()
            val b = m.groupValues[2].toIntOrNull()
            if (a != null && b != null) {
                lo = minOf(a, b)
                hi = maxOf(a, b)
            }
        }
        if (hi == Int.MAX_VALUE) hi -= 1
        return "Random number ($lo se $hi): ${Random.nextInt(lo, hi + 1)} 🎯"
    }

    private fun tryPercent(q: String): String? {
        val m = Regex(
            "(\\d+(?:\\.\\d+)?)\\s*(?:%|percent|pratishat|प्रतिशत)\\s*(?:of|ka|ki|ke)?\\s*(\\d+(?:\\.\\d+)?)"
        ).find(q) ?: return null
        val p = m.groupValues[1].toDoubleOrNull() ?: return null
        val n = m.groupValues[2].toDoubleOrNull() ?: return null
        return "${fmt(p)}% of ${fmt(n)} = ${fmt(p * n / 100.0)} 🧮"
    }

    private fun tryConvert(q: String): String? {
        val m = Regex("(-?\\d+(?:\\.\\d+)?)\\s*([a-z]+)\\s*(?:to|in|me|mein)\\s*([a-z]+)").find(q)
            ?: return null
        val v = m.groupValues[1].toDoubleOrNull() ?: return null
        val src = units[m.groupValues[2]] ?: return null
        val dst = units[m.groupValues[3]] ?: return null
        val r: Double = when (src + ">" + dst) {
            "km>mi" -> v * 0.621371
            "mi>km" -> v * 1.609344
            "kg>lb" -> v * 2.2046226
            "lb>kg" -> v / 2.2046226
            "c>f" -> v * 9.0 / 5.0 + 32.0
            "f>c" -> (v - 32.0) * 5.0 / 9.0
            "cm>in" -> v / 2.54
            "in>cm" -> v * 2.54
            "m>ft" -> v * 3.28084
            "ft>m" -> v / 3.28084
            else -> return null
        }
        return "${fmt(v)} ${m.groupValues[2]} = ${fmt(r)} ${m.groupValues[3]} 🔁"
    }

    private fun tryCalculate(text: String): String? {
        val cleaned = text.replace('×', '*').replace('÷', '/')
            .replace(Regex("(?<=\\d)\\s*[xX]\\s*(?=\\d)"), "*")
        val candidates = Regex("[0-9(.][0-9+\\-*/^().\\s]*").findAll(cleaned)
            .map { it.value.trim().trimEnd('+', '-', '*', '/', '^', '.', ' ') }
            .filter { c -> c.length >= 3 && c.drop(1).any { it in "+-*/^" } }
            .sortedByDescending { it.length }
            .toList()
        for (c in candidates) {
            try {
                val v = ExprParser(c).parse()
                if (v.isNaN() || v.isInfinite()) return "Zero se divide nahi kar sakte bhai! 🚫"
                return "$c = ${fmt(v)} 🧮"
            } catch (e: Exception) {
                // not a valid expression, try next candidate
            }
        }
        return null
    }
}

/** Tiny recursive-descent parser: + - * / ^ and parentheses. */
private class ExprParser(private val s: String) {
    private var pos = 0

    fun parse(): Double {
        val v = expr()
        skip()
        if (pos != s.length) throw IllegalArgumentException("extra input")
        return v
    }

    private fun skip() {
        while (pos < s.length && s[pos].isWhitespace()) pos++
    }

    private fun peek(): Char? {
        skip()
        return if (pos < s.length) s[pos] else null
    }

    private fun expr(): Double {
        var v = term()
        var c = peek()
        while (c == '+' || c == '-') {
            pos++
            val r = term()
            v = if (c == '+') v + r else v - r
            c = peek()
        }
        return v
    }

    private fun term(): Double {
        var v = power()
        var c = peek()
        while (c == '*' || c == '/') {
            pos++
            val r = power()
            v = if (c == '*') v * r else v / r
            c = peek()
        }
        return v
    }

    private fun power(): Double {
        val base = unary()
        if (peek() == '^') {
            pos++
            return Math.pow(base, power())
        }
        return base
    }

    private fun unary(): Double {
        val c = peek()
        if (c == '-') {
            pos++
            return -unary()
        }
        if (c == '+') {
            pos++
            return unary()
        }
        return atom()
    }

    private fun atom(): Double {
        if (peek() == '(') {
            pos++
            val v = expr()
            if (peek() != ')') throw IllegalArgumentException("missing )")
            pos++
            return v
        }
        val start = pos
        while (pos < s.length && (s[pos].isDigit() || s[pos] == '.')) pos++
        if (start == pos) throw IllegalArgumentException("number expected")
        return s.substring(start, pos).toDouble()
    }
}
