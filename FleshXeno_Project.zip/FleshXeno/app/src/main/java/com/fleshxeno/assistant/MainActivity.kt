package com.fleshxeno.assistant

import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Background = Color(0xFF090D18)
private val Panel = Color(0xFF151D30)
private val Accent = Color(0xFF8B7CFF)
private val TextMain = Color(0xFFF4F5FF)

private const val PREFS = "flesh_xeno"
private const val KEY_MESSAGES = "messages"
private const val WELCOME =
    "Hey! Main Flesh Xeno hoon. Main bina internet ke calculator, converter, time/date, jokes aur baatein kar sakta hoon. 'help' likho ya neeche ke buttons dabao!"

data class ChatMessage(val text: String, val fromUser: Boolean, val time: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { FleshXenoApp() }
    }
}

private fun now(): String = SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date())

private fun loadMessages(prefs: SharedPreferences): List<ChatMessage> {
    val raw = prefs.getString(KEY_MESSAGES, null) ?: return emptyList()
    return try {
        val arr = JSONArray(raw)
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            ChatMessage(o.getString("t"), o.getBoolean("u"), o.getString("h"))
        }
    } catch (e: Exception) {
        emptyList()
    }
}

private fun saveMessages(prefs: SharedPreferences, list: List<ChatMessage>) {
    val arr = JSONArray()
    list.takeLast(200).forEach {
        arr.put(JSONObject().put("t", it.text).put("u", it.fromUser).put("h", it.time))
    }
    prefs.edit().putString(KEY_MESSAGES, arr.toString()).apply()
}

@Composable
fun FleshXenoApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences(PREFS, Context.MODE_PRIVATE) }
    val messages = remember {
        mutableStateListOf<ChatMessage>().apply {
            val saved = loadMessages(prefs)
            if (saved.isEmpty()) add(ChatMessage(WELCOME, false, now())) else addAll(saved)
        }
    }
    var input by remember { mutableStateOf("") }
    var typing by remember { mutableStateOf(false) }
    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()

    LaunchedEffect(messages.size, typing) {
        val count = messages.size + if (typing) 1 else 0
        if (count > 0) listState.animateScrollToItem(count - 1)
    }

    fun send(text: String) {
        val q = text.trim()
        if (q.isEmpty() || typing) return
        messages.add(ChatMessage(q, true, now()))
        saveMessages(prefs, messages)
        input = ""
        typing = true
        scope.launch {
            delay(450)
            messages.add(ChatMessage(OfflineBrain.reply(q), false, now()))
            saveMessages(prefs, messages)
            typing = false
        }
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Accent, background = Background, surface = Panel,
            onBackground = TextMain, onSurface = TextMain
        )
    ) {
        Surface(Modifier.fillMaxSize(), color = Background) {
            Column(Modifier.fillMaxSize().systemBarsPadding().imePadding().padding(16.dp)) {

                // Header
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("FLESH XENO", color = TextMain, fontSize = 25.sp, fontWeight = FontWeight.Black)
                        Text("OFFLINE ASSISTANT", color = Accent, fontSize = 11.sp, letterSpacing = 2.sp)
                    }
                    Surface(color = Color(0xFF173A32), shape = RoundedCornerShape(50)) {
                        Text(
                            "● OFFLINE", color = Color(0xFF72E6B4),
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp), fontSize = 11.sp
                        )
                    }
                    TextButton(onClick = {
                        messages.clear()
                        messages.add(ChatMessage(WELCOME, false, now()))
                        saveMessages(prefs, messages)
                    }) {
                        Text("Clear", color = Color.Gray, fontSize = 12.sp)
                    }
                }
                Spacer(Modifier.height(12.dp))

                // Messages
                LazyColumn(
                    state = listState,
                    modifier = Modifier.weight(1f).fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    contentPadding = PaddingValues(vertical = 8.dp)
                ) {
                    items(messages) { msg ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = if (msg.fromUser) Arrangement.End else Arrangement.Start
                        ) {
                            Column(
                                Modifier.widthIn(max = 310.dp)
                                    .background(if (msg.fromUser) Color(0xFF5146A8) else Panel, RoundedCornerShape(18.dp))
                                    .padding(13.dp)
                            ) {
                                Text(
                                    if (msg.fromUser) "YOU" else "FLESH XENO",
                                    color = if (msg.fromUser) Color.White else Accent,
                                    fontSize = 10.sp, fontWeight = FontWeight.Bold
                                )
                                Spacer(Modifier.height(5.dp))
                                SelectionContainer {
                                    Text(msg.text, color = TextMain, fontSize = 15.sp)
                                }
                                Spacer(Modifier.height(5.dp))
                                Text(msg.time, color = Color.LightGray, fontSize = 9.sp)
                            }
                        }
                    }
                    if (typing) {
                        item {
                            Text("Flesh Xeno likh raha hai…", color = Color.Gray, fontSize = 12.sp)
                        }
                    }
                }

                // Quick buttons
                Row(
                    Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf(
                        "🕒 Time" to "time",
                        "📅 Date" to "date",
                        "😂 Joke" to "joke",
                        "💡 Quote" to "quote",
                        "🧠 Fact" to "fun fact",
                        "🪙 Coin" to "flip coin",
                        "🎲 Dice" to "roll dice",
                        "❓ Help" to "help"
                    ).forEach { (label, cmd) ->
                        Text(
                            label, color = TextMain, fontSize = 13.sp,
                            modifier = Modifier
                                .clip(RoundedCornerShape(50))
                                .background(Panel)
                                .clickable { send(cmd) }
                                .padding(horizontal = 14.dp, vertical = 8.dp)
                        )
                    }
                }

                // Input
                Row(
                    Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(28.dp))
                        .padding(horizontal = 15.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    BasicTextField(
                        value = input,
                        onValueChange = { input = it },
                        modifier = Modifier.weight(1f).padding(vertical = 10.dp),
                        textStyle = TextStyle(color = TextMain, fontSize = 15.sp),
                        cursorBrush = SolidColor(Accent),
                        maxLines = 4,
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                        keyboardActions = KeyboardActions(onSend = { send(input) }),
                        decorationBox = { inner ->
                            Box {
                                if (input.isEmpty()) Text("Message Flesh Xeno...", color = Color.Gray)
                                inner()
                            }
                        }
                    )
                    IconButton(onClick = { send(input) }) {
                        Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send", tint = Accent)
                    }
                }
                Spacer(Modifier.height(6.dp))
                Text(
                    "Works offline • Replies are generated locally from built-in rules",
                    color = Color.Gray, fontSize = 10.sp
                )
            }
        }
    }
}
